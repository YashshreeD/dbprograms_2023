import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()


prodid=int(input('Enter product id : '))
   
curs.execute("select * from mobiles where prodid=%d" %prodid) 
result=curs.fetchone()  
print(result)

if result:
    newprice=int(input('Enter new price : '))
    curs.execute("update mobiles set price=%d where prodid=%d" %(newprice,prodid))
    con.commit()
    print('price updated sucessefully')

else:
    print('Product not found')

    
con.close()
