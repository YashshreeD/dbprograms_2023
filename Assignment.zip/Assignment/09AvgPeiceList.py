import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()


curs.execute("select company, count(modelnm), avg(price), avg(rating) from mobiles group by company")
res=curs.fetchall()

print(res)


con.close()
