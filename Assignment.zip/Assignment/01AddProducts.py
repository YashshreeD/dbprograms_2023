import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

try:
  prodid=int(input('Enter product id : '))
  rodnm=input('Enter product name : ')
  company=input('Enter company : ')
  connectivity=input('Enter connectivity : ')
  ram=input('Enter ram : ')
  rom=input('Enter rom : ')
  col=input('Enter color : ')
  screen=input('Enter display in inches : ')
  battry=input('Enter battry : ')
  pros=input('Enter prosseor : ')
  price=int(input('Enter price : '))
  rating=input('Enter rating : ')
  curs.execute("insert into mobiles values(%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s',%d,'%s')" %(prodid,prodnm,company,connectivity,ram,rom,col,screen,battry,pros,price,rating))
  con.commit()
  print('new product added successfully')

except:
    prodid=0
    print('Invalid input')
    print('Only integer value')











con.close()


