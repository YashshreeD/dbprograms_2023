import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

prodid=int(input("Enter product id : "))

curs.execute("select * from mobiles where prodid=%d" %prodid)
result=curs.fetchall()

for data in result:
    print(data)

delete=input("Do you want do delete ? ")

if delete.lower() == "yes":
    curs.execute("delete from mobile where prodid=%d" %prodid)
    con.commit()

    print('Product deleted sucessuflly')

else:
    print('product not deleted')    


con.close()