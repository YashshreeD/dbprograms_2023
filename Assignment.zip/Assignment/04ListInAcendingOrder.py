import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

comnm=input('Enter company name : ')

curs.execute("select * from mobiles where company='%s' order by price " %comnm)

result=curs.fetchall()
if result:
   for res in result:
      print(res)

else:
    print('NO DATA FOUND')

    
con.close()

