import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

ram=input("Enter RAM in GB : ")
rom=input("Enter ROM in GB : ")

if ram.isdigit() and rom.isdigit():
    ram=int(ram)
    rom=int(rom)

    curs.execute("select * from mobiles where ram=%d and rom=%d " %(ram,rom))
    lst=curs.fetchall()
    
    for res in lst:
      print(res)

else:
    print('Invalid input.Enter INTEGER only.')


con.close()