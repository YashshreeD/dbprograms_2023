import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

modelnm=input('Enter model name : ')

curs.execute("select * from mobiles where modelnm='%s'" %modelnm)
data=curs.fetchone()

if data :
   print(data)

else:
    print('NO DATA FOUND')





con.close()