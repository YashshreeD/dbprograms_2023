import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()


try:
    modelnm = input('Enter model name : ')
    purpose = input('Enter purpose : ')

    curs.execute("UPDATE mobiles SET purpose='%s' WHERE modelnm='%s'" % (purpose, modelnm))
    con.commit()
    print('Purpose updated successfully')


except:
    print('Invalid Data')

con.close()