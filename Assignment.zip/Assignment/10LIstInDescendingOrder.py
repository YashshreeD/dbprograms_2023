import pymysql

con=pymysql.connect(host='bciex1cp8ggow2j2mleg-mysql.services.clever-cloud.com',user='u01xn8gndqjhoe4q',password='vrOqEEnJE6CHOWjHeGlH',database='bciex1cp8ggow2j2mleg')
curs=con.cursor()

rom=input('Enter ROM in GB : ')

curs.execute("select * from mobiles where rom='%s' order by rom DESC" %rom)

result=curs.fetchall()

for res in result:
    print(res)

con.close()